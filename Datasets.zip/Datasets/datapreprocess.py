# Open the file for reading
with open('FrozenLake_trajectories_1m.txt', 'r') as file:
    # Read all lines from the file
    lines = file.readlines()

# Process each line and convert the third column to integers
for i in range(len(lines)):
    # Split the line into columns
    columns = lines[i].split()

    # Convert the third column to an integer
    columns[2] = str(int(float(columns[2])))

    # Join the columns back into a line
    lines[i] = ' '.join(columns) + '\n'

# Open the file for writing and save the updated content
with open('FrozenLake_trajectories_1m.txt', 'w') as file:
    file.writelines(lines)

