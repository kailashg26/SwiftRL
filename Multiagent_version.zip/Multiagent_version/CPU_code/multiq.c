#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <inttypes.h>
#include <time.h>

#define NUM_STATES 16
#define NUM_ACTIONS 4
#define ALPHA 0.1
#define GAMMA 0.95
#define NUM_EPISODES 10
#define BATCH_SIZE 500
#define BATCH_CAPACITY 10000
#define NUM_AGENTS 1000

double q_tables[NUM_AGENTS][NUM_STATES][NUM_ACTIONS] = {{{0.0}}};

typedef struct {
    int state;
    int action;
    double reward;
    int next_state;
} Experience;

void initialize_q_tables() {
    for (int agent = 0; agent < NUM_AGENTS; agent++) {
        for (int state = 0; state < NUM_STATES; state++) {
            for (int action = 0; action < NUM_ACTIONS; action++) {
                q_tables[agent][state][action] = 0.0;
            }
        }
    }
}

void update_q_table(Experience experience, double q_table[NUM_STATES][NUM_ACTIONS]) {
    int s = experience.state;
    int a = experience.action;
    double r = experience.reward;
    int next_s = experience.next_state;

    // Perform Q-value update
    double max_next_q = 0;
    for (int next_a = 0; next_a < NUM_ACTIONS; next_a++) {
        if (q_table[next_s][next_a] > max_next_q) {
            max_next_q = q_table[next_s][next_a];
        }
    }
    q_table[s][a] += ALPHA * (r + GAMMA * max_next_q - q_table[s][a]);
}

void print_q_table(double q_table[NUM_STATES][NUM_ACTIONS], int agent) {
    printf("Q-table for agent %d:\n", agent);
    for (int state = 0; state < NUM_STATES; state++) {
        for (int action = 0; action < NUM_ACTIONS; action++) {
            printf("Q(%d, %d) = %f\n", state, action, q_table[state][action]);
        }
    }
    printf("\n");
}

int main() {
    clock_t start_time = clock();

    initialize_q_tables();

    FILE *file = fopen("/home/upmem0013/kailashg26/Kailash_ISPASS2024/Datasets/FrozenLake_trajectories_10k.txt", "r");
    if (file == NULL) {
        perror("Error opening the data file");
        return 1;
    }

    Experience dataset[BATCH_CAPACITY];
    int num_samples = 0;
    Experience experience;

    while (fscanf(file, "%d %d %lf %d", &experience.state, &experience.action, &experience.reward, &experience.next_state) != EOF) {
        dataset[num_samples] = experience;
        num_samples++;
    }

    fclose(file);

    int mini_batch = num_samples / BATCH_SIZE;
    Experience batch[BATCH_SIZE];

    for (int agent = 0; agent < NUM_AGENTS; agent++) {
        double (*q_table)[NUM_ACTIONS] = q_tables[agent];

        for (int episode = 0; episode < NUM_EPISODES; episode++) {
            for (int batch_window = 0; batch_window < mini_batch; batch_window++) {
                for (int i = batch_window * BATCH_SIZE; i < BATCH_SIZE + batch_window * BATCH_SIZE; i++) {
                    batch[i - batch_window * BATCH_SIZE] = dataset[i];
                    update_q_table(batch[i - batch_window * BATCH_SIZE], q_table);
                }
            }
        }

        // Print Q-table for each agent
        print_q_table(q_table, agent);
    }

    clock_t end_time = clock();
    double total_time_taken = ((double)(end_time - start_time)) / CLOCKS_PER_SEC;

    printf("Total time taken for training %d agents: %f seconds\n", NUM_AGENTS, total_time_taken);

    return 0;
}

