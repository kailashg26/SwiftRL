#include <stdio.h>
#include <mram.h>
#include <barrier.h>
#include <inttypes.h>
#include <perfcounter.h>
#include <defs.h>

BARRIER_INIT(my_barrier, NR_TASKLETS)

#define VECTOR_SIZE (2 << 16)

__mram_noinit uint8_t first_vector[VECTOR_SIZE];
__mram_noinit uint8_t second_vector[VECTOR_SIZE];
__mram_noinit uint8_t third_vector[VECTOR_SIZE];
__mram_noinit uint8_t fourth_vector[VECTOR_SIZE];

//#define NR_ELEM_PER_TASKLETS (VECTOR_SIZE / NR_TASKLETS)

// Q-learning parameters
#define LEARNING_RATE 0.1
#define DISCOUNT_FACTOR 0.95
#define NUM_ITERATIONS 1000
#define BATCH_SIZE 500
#define BATCH_CAPACITY 1000000
#define NUM_ACTIONS 4  
#define NUM_STATES 16

__host uint8_t q_table[NUM_STATES][NUM_ACTIONS] = {{0.0}}; 


int main() {
    if (me() == 0) {
        perfcounter_config(COUNT_CYCLES, true);
    }

    printf("%d %d %d %d", first_vector[0], first_vector[1], first_vector[2], first_vector[3]);

    barrier_wait(&my_barrier);
 
    for (int iter = 0; iter < NUM_ITERATIONS; iter++) {

        for (int i = 0; i < 10000; i++) {
            // Get state and action from the dataset
            uint8_t state = first_vector[i];
            uint8_t action = second_vector[i];
            uint8_t reward = third_vector[i];
            uint8_t next_state = fourth_vector[i];
        

            // Compute the Q-value for the current state-action pair
            uint8_t q_value = q_table[state][action];

            // Compute the maximum Q-value for the next state
            uint8_t max_q_value = 0;
            for (int a = 0; a < NUM_ACTIONS; a++) {
                if (q_table[next_state][a] > max_q_value) {
                    max_q_value = q_table[next_state][a];
                }
            }

            // Updating the Q-value using the Q-learning formula
            q_table[state][action] += LEARNING_RATE * (reward + DISCOUNT_FACTOR * max_q_value -  q_table[state][action]);
        }
        barrier_wait(&my_barrier);
    }

    if (me() == 0) {
        perfcounter_t end_time = perfcounter_get();

        // Print the Q-table
        printf("Learned Q-table:\n");
        for (int state = 0; state < NUM_STATES; state++) {
            for (int action = 0; action < NUM_ACTIONS; action++) {
                printf("Q(%u, %u) = %u\n", state, action, q_table[state][action]);
            }
        }
        printf("Execution time: %lu cycles\n", end_time);
    }

    return 0;
}

