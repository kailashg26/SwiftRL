#!/usr/bin/env python3

from dpu import DpuSet
from dpu import ALLOCATE_ALL
import argparse
import os
import random
import struct
import sys
import random
import csv
from sys import stdout
import time
import collections


BUFFER_SIZE = 2 << 16
DPU_BUFFER = 'dpu_mram_buffer'
#RESULT_SIZE = 4


def read_data_from_file(file_path):
    column1 = []
    column2 = []
    column3 = []
    column4 = []

    with open(file_path, 'r') as file:
        for line in file:
            values = line.strip().split()

            column1.append(int(values[0]))
            column2.append(int(values[1]))
            column3.append(int(values[2]))
            column4.append(int(values[3]))

    list1 = bytearray(column1)
    list2 = bytearray(column2)
    list3 = bytearray(column3)
    list4 = bytearray(column4)

    return list1, list2, list3, list4


def main(nr_dpus, nr_tasklets):
    obs, act, rew, next_obs = read_data_from_file("/home/upmem0013/kailashg26/main_ispass2024/PIM_MARL/Datasets/FrozenLake_trajectories_10m.txt")
    print('Load input data')
    state_actions = collections.defaultdict(set)

    with DpuSet(nr_dpus, binary="Qlearning") as dpus:
        print('Allocated {} DPU(s)'.format(len(dpus)))

        
        for i, dpu in enumerate(dpus):
            chunk_size = len(obs) // nr_dpus
            start = i * chunk_size
            end = (i + 1) * chunk_size
            dpu.copy('first_vector', obs[start:end])
            dpu.copy('second_vector', act[start:end])
            dpu.copy('third_vector', rew[start:end])
            dpu.copy('fourth_vector', next_obs[start:end])

        print('Run program on DPU(s)')
        start = time.time()
        dpus.exec()
        end = time.time()

        results = [bytearray(4 * 16) for _ in dpus]
        print('Retrieve results')
        count = 0

        dpus.copy(results, 'q_table')
        #print(results)
        
        results_i = [[] for dpu in range(len(dpus))]
        for x in range(len(dpus)):
            for element in results[x]:
                results_i[x].append(element)
        # Print the two-dimensional array
        for i in range(len(dpus)):
            for state_id in range(0, len(results_i[i]), 2):
                state_actions[(state_id, 0)].add(results_i[i][state_id])
                state_actions[(state_id, 1)].add(results_i[i][state_id + 1])


        for state_action in state_actions:
            q_value = sum(state_actions[state_action]) // len(dpus)
            print(f"Q{state_action[0] // 2, state_action[1]} = {q_value}")


        print(end - start, "hello, this is PIM kernel time in sec")

        


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('nr_dpus')
    parser.add_argument('nr_tasklets', type=int)
    args = parser.parse_args()

    if args.nr_dpus == 'DPU_ALLOCATE_ALL':
        nr_dpus = ALLOCATE_ALL
    else:
        try:
            nr_dpus = int(args.nr_dpus)
        except ValueError:
            parser.error("argument nr_dpus: invalid value: '{}'".format(args.nr_dpus))
            sys.exit(os.EX_USAGE)

    main(nr_dpus, args.nr_tasklets)

